export interface ErrorObject {
    message: string;
    type: string;
    code?: string | null;
    /**
     * Debug information including input and output token IDs and strings. Only present
     * when debug=true in the request.
     */
    debug?: ErrorObject.Debug;
    failed_generation?: string | null;
    param?: string | null;
    schema_code?: string | null;
    schema_kind?: string | null;
    schema_path?: string | null;
    /**
     * Segments of the schema path relevant to validation errors.
     */
    schema_path_segments?: Array<string>;
}
export declare namespace ErrorObject {
    /**
     * Debug information including input and output token IDs and strings. Only present
     * when debug=true in the request.
     */
    interface Debug {
        /**
         * Token IDs for the input.
         */
        input_token_ids?: Array<number>;
        /**
         * Token strings for the input.
         */
        input_tokens?: Array<string>;
        /**
         * Token IDs for the output.
         */
        output_token_ids?: Array<number>;
        /**
         * Token strings for the output.
         */
        output_tokens?: Array<string>;
    }
}
export interface FunctionDefinition {
    /**
     * The name of the function to be called. Must be a-z, A-Z, 0-9, or contain
     * underscores and dashes, with a maximum length of 64.
     */
    name: string;
    /**
     * A description of what the function does, used by the model to choose when and
     * how to call the function.
     */
    description?: string;
    /**
     * Function parameters defined as a JSON Schema object. Refer to
     * https://json-schema.org/understanding-json-schema/ for schema documentation.
     */
    parameters?: FunctionParameters;
    /**
     * Whether to enable strict schema adherence when generating the output. If set to
     * true, the model will always follow the exact schema defined in the `schema`
     * field. Only a subset of JSON Schema is supported when `strict` is `true`.
     */
    strict?: boolean;
}
/**
 * Function parameters defined as a JSON Schema object. Refer to
 * https://json-schema.org/understanding-json-schema/ for schema documentation.
 */
export type FunctionParameters = {
    [key: string]: unknown;
};
//# sourceMappingURL=shared.d.ts.map