export declare const VERSION = "1.2.0";
//# sourceMappingURL=version.d.mts.map